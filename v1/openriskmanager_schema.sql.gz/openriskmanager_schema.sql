/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.22-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: OpenRiskManager
-- ------------------------------------------------------
-- Server version	10.6.22-MariaDB-0ubuntu0.22.04.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `base_solicitacao_controlador`
--

DROP TABLE IF EXISTS `base_solicitacao_controlador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_solicitacao_controlador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cad_pdca_responsavel`
--

DROP TABLE IF EXISTS `cad_pdca_responsavel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cad_pdca_responsavel` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` bigint(20) unsigned NOT NULL,
  `estabelecimento` bigint(20) unsigned NOT NULL,
  `nome` varchar(120) NOT NULL,
  `email` varchar(160) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_resp_empresa_estab_nome` (`empresa`,`estabelecimento`,`nome`),
  KEY `idx_resp_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categoria_dados_pessoais`
--

DROP TABLE IF EXISTS `categoria_dados_pessoais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoria_dados_pessoais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_empresa`
--

DROP TABLE IF EXISTS `check_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `check_empresa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homologacao` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contrato`
--

DROP TABLE IF EXISTS `contrato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contrato` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identificador` varchar(45) DEFAULT NULL,
  `vigencia_inicio` datetime DEFAULT NULL,
  `vigencia_final` datetime DEFAULT NULL,
  `resp_legal` varchar(99) DEFAULT NULL,
  `id_resp_legal` varchar(45) DEFAULT NULL,
  `endereco_resp_legal` varchar(256) DEFAULT NULL,
  `bairro_resp_legal` varchar(45) DEFAULT NULL,
  `cidade_resp_legal` varchar(45) DEFAULT NULL,
  `telefone_resp_legal` varchar(45) DEFAULT NULL,
  `email_resp_legal` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identificador_UNIQUE` (`identificador`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `controles_aplicados_transferencias`
--

DROP TABLE IF EXISTS `controles_aplicados_transferencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `controles_aplicados_transferencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dado_pessoal`
--

DROP TABLE IF EXISTS `dado_pessoal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dado_pessoal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  `narrativa` varchar(256) DEFAULT NULL,
  `dado_sensivel` int(11) DEFAULT NULL,
  `empresa` int(11) DEFAULT NULL,
  `departamento` int(11) DEFAULT NULL,
  `processo` int(11) DEFAULT NULL,
  `narrativa_motivo_tratamento_declarante` varchar(512) DEFAULT NULL,
  `declarante` varchar(45) DEFAULT NULL,
  `data_avaliacao` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `departamento`
--

DROP TABLE IF EXISTS `departamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departamento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` int(11) DEFAULT NULL,
  `estabelecimento` int(11) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `ccusto` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_departamento_01_idx` (`empresa`),
  CONSTRAINT `fk_departamento_01` FOREIGN KEY (`empresa`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `direito_titular`
--

DROP TABLE IF EXISTS `direito_titular`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `direito_titular` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dpo`
--

DROP TABLE IF EXISTS `dpo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dpo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  `tipo` int(11) DEFAULT NULL,
  `id_usuario` varchar(45) DEFAULT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `sobrenome` varchar(45) DEFAULT NULL,
  `nome_completo` varchar(99) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `telefone` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  `rsocial` varchar(99) DEFAULT NULL,
  `endereco` varchar(256) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  `pais` varchar(45) DEFAULT NULL,
  `cep` varchar(45) DEFAULT NULL,
  `cnpj` varchar(45) DEFAULT NULL,
  `ie` varchar(45) DEFAULT NULL,
  `im` varchar(45) DEFAULT NULL,
  `logo` longblob DEFAULT NULL,
  `website` varchar(99) DEFAULT NULL,
  `email` varchar(99) DEFAULT NULL,
  `data_registro` datetime DEFAULT NULL,
  `usuario_registro` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `contrato` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_empresa_01_idx` (`status`),
  KEY `fk_empresa_02_idx` (`contrato`),
  CONSTRAINT `fk_empresa_01` FOREIGN KEY (`status`) REFERENCES `status_geral` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_empresa_02` FOREIGN KEY (`contrato`) REFERENCES `contrato` (`identificador`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `empresa_config`
--

DROP TABLE IF EXISTS `empresa_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` int(11) DEFAULT NULL,
  `trata_dados_pessoais` int(11) DEFAULT NULL,
  `trata_dados_pessoais_massivos` int(11) DEFAULT NULL,
  `trata_dados_pessoais_sensiveis` int(11) DEFAULT NULL,
  `trata_dados_pessoais_criancas_adolecentes` int(11) DEFAULT NULL,
  `transfere_dados_internacionais` int(11) DEFAULT NULL,
  `decisoes_automatizadas_tratamento` int(11) DEFAULT NULL,
  `historio_vazamento_dados` int(11) DEFAULT NULL,
  `historico_incidentes_seguranca_informacao` int(11) DEFAULT NULL,
  `dpia` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `empresa_dpo`
--

DROP TABLE IF EXISTS `empresa_dpo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa_dpo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` int(11) DEFAULT NULL,
  `dpo` int(11) DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_final` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_empresa_dpo_01_idx` (`dpo`),
  KEY `fk_empresa_dpo_02_idx` (`empresa`),
  KEY `fk_empresa_dpo_03_idx` (`status`),
  CONSTRAINT `fk_empresa_dpo_01` FOREIGN KEY (`dpo`) REFERENCES `dpo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_empresa_dpo_02` FOREIGN KEY (`empresa`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_empresa_dpo_03` FOREIGN KEY (`status`) REFERENCES `status_geral` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `estabelecimento`
--

DROP TABLE IF EXISTS `estabelecimento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `estabelecimento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` int(11) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `cod_erp` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `finalidade_tratamento_dados_pessoais`
--

DROP TABLE IF EXISTS `finalidade_tratamento_dados_pessoais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `finalidade_tratamento_dados_pessoais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `forma_tratamento_dados_pessoais`
--

DROP TABLE IF EXISTS `forma_tratamento_dados_pessoais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `forma_tratamento_dados_pessoais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mapa_dados`
--

DROP TABLE IF EXISTS `mapa_dados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mapa_dados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `01_empresa` int(11) DEFAULT NULL,
  `01_estabelecimento` int(11) DEFAULT NULL,
  `01_departamento` int(11) DEFAULT NULL,
  `01_processo` int(11) DEFAULT NULL,
  `01_descricao` varchar(45) DEFAULT NULL,
  `01_narrativa_motivo_tratamento_declarante` varchar(256) DEFAULT NULL,
  `01_declarante` varchar(45) DEFAULT NULL,
  `01_data_avaliacao` datetime DEFAULT NULL,
  `01_dado_sensivel` int(11) DEFAULT NULL,
  `01_dado_pessoal` varchar(512) DEFAULT NULL,
  `01_finalidade_tratamento` varchar(512) DEFAULT NULL,
  `01_forma_tratamento` varchar(512) DEFAULT NULL COMMENT 'formulario\nwebsite\nsistema informatico\ninteligencia artificial\nauto-declaracao\nBusiness Analis',
  `01_tipo_tratamento` varchar(512) DEFAULT NULL COMMENT 'coleta,captura,compra,extracao,compatilhamento,envio,delecao,guarda\n',
  `02_prazo_retencao` int(11) DEFAULT NULL,
  `02_unidade_retencao` int(11) DEFAULT NULL,
  `03_compartilha_dado` int(11) DEFAULT NULL,
  `03_finalidade_compartilhamento` int(11) DEFAULT NULL,
  `03_compartilha_com_quem` varchar(512) DEFAULT NULL,
  `01_base_legal_tratamento` varchar(256) DEFAULT NULL,
  `04_transfere_dado_internacional` int(11) DEFAULT NULL,
  `04_paises_transferencia` varchar(256) DEFAULT NULL,
  `04_controles_aplicados_transferencia` varchar(512) DEFAULT NULL,
  `01_categoria_dados_tratados` varchar(256) DEFAULT NULL,
  `05_trata_criancas_adolecentes` int(11) DEFAULT NULL,
  `05_tratamento_dados_risco` int(11) DEFAULT NULL COMMENT 'Há tratamento de dados adicionais que podem representar risco para titulares (e.g. dados financeiros)?',
  `06_quem_sao_titulares` varchar(512) DEFAULT NULL,
  `06_natureza_relacionamento_titulares` varchar(512) DEFAULT NULL,
  `07_como_sao_coletados` varchar(512) DEFAULT NULL,
  `08_operador` varchar(256) DEFAULT NULL,
  `08_contato_operador` varchar(256) DEFAULT NULL,
  `09_medidas_seguranca_sao_aplicadas` int(11) DEFAULT NULL,
  `09_medidas_aplicadas` varchar(256) DEFAULT NULL,
  `09_controles_aplicados` varchar(256) DEFAULT NULL,
  `10_responsável_coleta` varchar(256) DEFAULT NULL,
  `10_responsavel_operacao` varchar(256) DEFAULT NULL,
  `11_interesse_legitimo_controlador` int(11) DEFAULT NULL,
  `11_descricao_interesse_legitimo_controlador` varchar(256) DEFAULT NULL,
  `11_relatorio_avaliacao_interesse_legitimo` int(11) DEFAULT NULL,
  `11_doc_relatorio_avaliacao_interesse_legitimo` longblob DEFAULT NULL,
  `12_direito_titulares_aplicaveis` varchar(256) DEFAULT NULL,
  `13_tomada_decisao_automatizada` int(11) DEFAULT NULL,
  `13_criterios_procedimentos_automatizados` varchar(512) DEFAULT NULL,
  `13_tratamento_baseado_consentimento` int(11) DEFAULT NULL,
  `13_local_registro_consentimento` varchar(256) DEFAULT NULL,
  `13_doc_local_registro_consentimento` longblob DEFAULT NULL,
  `14_local_armazenamento_dados_coletados` varchar(256) DEFAULT NULL,
  `14_necessidade_ripdp` int(11) DEFAULT NULL,
  `14_status_ripdp` int(11) DEFAULT NULL,
  `14_local_armazenamento_ripdp` varchar(256) DEFAULT NULL,
  `14_doc_ripdp` longblob DEFAULT NULL,
  `15_historio_incidente_violacao` int(11) DEFAULT NULL,
  `15_registro_violacao_dados_pessoais` varchar(256) DEFAULT NULL,
  `15_impactos_violacao` varchar(256) DEFAULT NULL,
  `15_fonte_deteccao_violacao` int(11) DEFAULT NULL,
  `15_documento_analise_violacao` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_dado_pessoal_01_idx` (`01_empresa`),
  KEY `fk_dado_pessoal_02_idx` (`01_departamento`),
  KEY `fk_dado_pessoal_03_idx` (`01_processo`),
  KEY `fk_rotdp_01_idx` (`01_dado_sensivel`,`03_compartilha_dado`,`04_transfere_dado_internacional`,`05_trata_criancas_adolecentes`,`09_medidas_seguranca_sao_aplicadas`,`11_interesse_legitimo_controlador`,`13_tomada_decisao_automatizada`,`13_tratamento_baseado_consentimento`,`14_necessidade_ripdp`,`15_historio_incidente_violacao`),
  KEY `fk_rotdp_01_idx1` (`03_compartilha_dado`),
  CONSTRAINT `fk_dado_pessoal_01` FOREIGN KEY (`01_empresa`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_dado_pessoal_02` FOREIGN KEY (`01_departamento`) REFERENCES `departamento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_dado_pessoal_03` FOREIGN KEY (`01_processo`) REFERENCES `processo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_rotdp_01` FOREIGN KEY (`03_compartilha_dado`) REFERENCES `opcoes_menu` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_rotdp_02` FOREIGN KEY (`01_dado_sensivel`) REFERENCES `opcoes_menu` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Registro das operações de tratamento de Dados Pessoais';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `medidas_seguranca_aplicaveis`
--

DROP TABLE IF EXISTS `medidas_seguranca_aplicaveis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medidas_seguranca_aplicaveis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mov_pdca_ciclo`
--

DROP TABLE IF EXISTS `mov_pdca_ciclo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mov_pdca_ciclo` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` bigint(20) unsigned NOT NULL,
  `estabelecimento` bigint(20) unsigned NOT NULL,
  `risco_id` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `objetivo` text DEFAULT NULL,
  `responsavel_id` bigint(20) unsigned DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_prevista_fim` date DEFAULT NULL,
  `status` enum('ABERTO','EM_ANDAMENTO','CONCLUIDO','CANCELADO') NOT NULL DEFAULT 'ABERTO',
  `gut_inicial` int(11) DEFAULT NULL,
  `gut_alvo` int(11) DEFAULT NULL,
  `gut_final` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pdca_ciclo_risco` (`empresa`,`estabelecimento`,`risco_id`),
  KEY `idx_pdca_ciclo_risco` (`risco_id`),
  KEY `idx_pdca_ciclo_resp` (`responsavel_id`),
  KEY `idx_pdca_ciclo_status` (`status`),
  CONSTRAINT `fk_pdca_ciclo_resp` FOREIGN KEY (`responsavel_id`) REFERENCES `cad_pdca_responsavel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_pdca_ciclo_risco` FOREIGN KEY (`risco_id`) REFERENCES `riscos` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER trg_pdca_ciclo_bu
BEFORE UPDATE ON mov_pdca_ciclo
FOR EACH ROW
BEGIN
  IF NEW.status = 'CONCLUIDO' AND OLD.status <> 'CONCLUIDO' THEN
    IF EXISTS (
      SELECT 1 FROM mov_pdca_tarefa t
       WHERE t.ciclo_id = OLD.id
         AND t.status <> 'CONCLUIDA'
    ) THEN
      SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Não é possível concluir o ciclo: existem tarefas não concluídas.';
    END IF;
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `mov_pdca_tarefa`
--

DROP TABLE IF EXISTS `mov_pdca_tarefa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mov_pdca_tarefa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` bigint(20) unsigned NOT NULL,
  `estabelecimento` bigint(20) unsigned NOT NULL,
  `ciclo_id` bigint(20) unsigned NOT NULL,
  `etapa` enum('PLAN','DO','CHECK','ACT') NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descricao` text DEFAULT NULL,
  `responsavel_id` bigint(20) unsigned DEFAULT NULL,
  `data_prevista` date DEFAULT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  `status` enum('ABERTA','EM_ANDAMENTO','CONCLUIDA','CANCELADA') NOT NULL DEFAULT 'ABERTA',
  `custo_previsto` decimal(16,2) DEFAULT NULL,
  `custo_real` decimal(16,2) DEFAULT NULL,
  `eficacia_prevista_pct` decimal(5,2) DEFAULT NULL,
  `eficacia_real_pct` decimal(5,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_pdca_tarefa_ciclo` (`ciclo_id`),
  KEY `idx_pdca_tarefa_resp` (`responsavel_id`),
  KEY `idx_pdca_tarefa_status` (`status`),
  KEY `idx_pdca_tarefa_etapa` (`etapa`),
  CONSTRAINT `fk_pdca_tarefa_ciclo` FOREIGN KEY (`ciclo_id`) REFERENCES `mov_pdca_ciclo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pdca_tarefa_resp` FOREIGN KEY (`responsavel_id`) REFERENCES `cad_pdca_responsavel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER trg_pdca_tarefa_ai
AFTER INSERT ON mov_pdca_tarefa
FOR EACH ROW
BEGIN
  INSERT INTO mov_pdca_tarefa_hist (tarefa_id, old_status, new_status, changed_by_id)
  VALUES (NEW.id, NULL, NEW.status, NEW.responsavel_id);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER trg_pdca_tarefa_au
AFTER UPDATE ON mov_pdca_tarefa
FOR EACH ROW
BEGIN
  IF (OLD.status <> NEW.status) THEN
    INSERT INTO mov_pdca_tarefa_hist (tarefa_id, old_status, new_status, changed_by_id)
    VALUES (NEW.id, OLD.status, NEW.status, NEW.responsavel_id);
  END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `mov_pdca_tarefa_anexo`
--

DROP TABLE IF EXISTS `mov_pdca_tarefa_anexo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mov_pdca_tarefa_anexo` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tarefa_id` bigint(20) unsigned NOT NULL,
  `uri` varchar(500) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_anx_tarefa` (`tarefa_id`),
  CONSTRAINT `fk_anx_tarefa` FOREIGN KEY (`tarefa_id`) REFERENCES `mov_pdca_tarefa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mov_pdca_tarefa_comentario`
--

DROP TABLE IF EXISTS `mov_pdca_tarefa_comentario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mov_pdca_tarefa_comentario` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tarefa_id` bigint(20) unsigned NOT NULL,
  `autor_id` bigint(20) unsigned DEFAULT NULL,
  `comentario` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_com_tarefa` (`tarefa_id`),
  KEY `idx_com_autor` (`autor_id`),
  CONSTRAINT `fk_com_autor` FOREIGN KEY (`autor_id`) REFERENCES `cad_pdca_responsavel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_com_tarefa` FOREIGN KEY (`tarefa_id`) REFERENCES `mov_pdca_tarefa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mov_pdca_tarefa_hist`
--

DROP TABLE IF EXISTS `mov_pdca_tarefa_hist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mov_pdca_tarefa_hist` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tarefa_id` bigint(20) unsigned NOT NULL,
  `old_status` varchar(30) DEFAULT NULL,
  `new_status` varchar(30) NOT NULL,
  `changed_by_id` bigint(20) unsigned DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_hist_tarefa` (`tarefa_id`),
  KEY `idx_hist_changed_by` (`changed_by_id`),
  CONSTRAINT `fk_hist_changed_by` FOREIGN KEY (`changed_by_id`) REFERENCES `cad_pdca_responsavel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_hist_tarefa` FOREIGN KEY (`tarefa_id`) REFERENCES `mov_pdca_tarefa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notif_inbox`
--

DROP TABLE IF EXISTS `notif_inbox`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notif_inbox` (
  `inbox_id` int(11) NOT NULL AUTO_INCREMENT,
  `notif_id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `notif_dtsent` datetime NOT NULL DEFAULT current_timestamp(),
  `notif_ontop` int(11) NOT NULL DEFAULT 0,
  `notif_isread` int(11) NOT NULL DEFAULT 0,
  `notif_dtread` datetime DEFAULT NULL,
  `notif_tags` varchar(255) DEFAULT NULL,
  `notif_important` int(11) DEFAULT NULL,
  PRIMARY KEY (`inbox_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notif_notifications`
--

DROP TABLE IF EXISTS `notif_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notif_notifications` (
  `notif_id` int(11) NOT NULL AUTO_INCREMENT,
  `notif_title` varchar(255) NOT NULL,
  `notif_message` text NOT NULL,
  `notif_dtcreated` datetime NOT NULL DEFAULT current_timestamp(),
  `notif_ontop` int(11) NOT NULL DEFAULT 0,
  `notif_dtexpire` datetime DEFAULT NULL,
  `notif_categ` varchar(60) DEFAULT NULL,
  `notif_login_sender` varchar(255) NOT NULL,
  `notif_type` varchar(60) DEFAULT NULL,
  `notif_link` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`notif_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notif_pref`
--

DROP TABLE IF EXISTS `notif_pref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notif_pref` (
  `login` varchar(255) NOT NULL,
  `receive_email` int(11) NOT NULL DEFAULT 0,
  `receive_sms` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notif_profiles`
--

DROP TABLE IF EXISTS `notif_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notif_profiles` (
  `profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(255) DEFAULT NULL,
  `profile_users` text DEFAULT NULL,
  `profile_groups` text DEFAULT NULL,
  `profile_public` int(11) NOT NULL DEFAULT 0,
  `profile_owner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notif_tags`
--

DROP TABLE IF EXISTS `notif_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notif_tags` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_title` varchar(50) NOT NULL,
  `login` varchar(255) NOT NULL,
  `tag_color` varchar(100) DEFAULT NULL,
  `tag_active` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notif_user_tags`
--

DROP TABLE IF EXISTS `notif_user_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notif_user_tags` (
  `user_tags_id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) NOT NULL,
  `login_sender` varchar(255) NOT NULL,
  `tags` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_tags_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `opcoes_menu`
--

DROP TABLE IF EXISTS `opcoes_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `opcoes_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `paises`
--

DROP TABLE IF EXISTS `paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `parecer_dpo`
--

DROP TABLE IF EXISTS `parecer_dpo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `parecer_dpo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `processo`
--

DROP TABLE IF EXISTS `processo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `processo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` int(11) DEFAULT NULL,
  `estabelecimento` int(11) DEFAULT NULL,
  `departamento` int(11) DEFAULT NULL,
  `descricao` varchar(99) DEFAULT NULL,
  `img_processo` longblob DEFAULT NULL,
  `dpo` int(11) DEFAULT NULL,
  `parecer_dpo` text DEFAULT NULL,
  `data_parecer_dpo` datetime DEFAULT NULL,
  `repasse_dado` int(11) DEFAULT NULL,
  `repasse_internacional_dado` int(11) DEFAULT NULL,
  `tratamento_dado_menor_adolecente` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_processo_01_idx` (`empresa`),
  KEY `fk_processo_02_idx` (`departamento`),
  KEY `fk_processo_03_idx` (`dpo`),
  CONSTRAINT `fk_processo_01` FOREIGN KEY (`empresa`) REFERENCES `empresa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_processo_02` FOREIGN KEY (`departamento`) REFERENCES `departamento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_processo_03` FOREIGN KEY (`dpo`) REFERENCES `dpo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `raci_atividade`
--

DROP TABLE IF EXISTS `raci_atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `raci_atividade` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` bigint(20) unsigned NOT NULL DEFAULT 1,
  `estabelecimento` bigint(20) unsigned NOT NULL DEFAULT 1,
  `area` enum('SUPORTE','SEGURANCA') NOT NULL,
  `categoria_id` bigint(20) unsigned DEFAULT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_raci_atividade_empresa_estab_area_nome` (`empresa`,`estabelecimento`,`area`,`nome`),
  KEY `idx_raci_atividade_nome` (`nome`),
  KEY `fk_raci_atividade_categoria` (`categoria_id`),
  CONSTRAINT `fk_raci_atividade_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `raci_categoria` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=265 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `raci_categoria`
--

DROP TABLE IF EXISTS `raci_categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `raci_categoria` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` bigint(20) unsigned NOT NULL DEFAULT 1,
  `estabelecimento` bigint(20) unsigned NOT NULL DEFAULT 1,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_raci_categoria_empresa_estab_nome` (`empresa`,`estabelecimento`,`nome`),
  KEY `idx_raci_categoria_nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `raci_mov`
--

DROP TABLE IF EXISTS `raci_mov`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `raci_mov` (
  `atividade_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `tipo` enum('R','A','C','I') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`atividade_id`,`role_id`,`tipo`),
  KEY `fk_mov_raci_role` (`role_id`),
  CONSTRAINT `fk_mov_raci_atividade` FOREIGN KEY (`atividade_id`) REFERENCES `raci_atividade` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mov_raci_role` FOREIGN KEY (`role_id`) REFERENCES `raci_role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `raci_role`
--

DROP TABLE IF EXISTS `raci_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `raci_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` bigint(20) unsigned NOT NULL DEFAULT 1,
  `estabelecimento` bigint(20) unsigned NOT NULL DEFAULT 1,
  `codigo` varchar(60) DEFAULT NULL,
  `nome` varchar(120) NOT NULL,
  `descricao` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_raci_role_empresa_estab_nome` (`empresa`,`estabelecimento`,`nome`),
  KEY `idx_raci_role_nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relacao_controlador`
--

DROP TABLE IF EXISTS `relacao_controlador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `relacao_controlador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `riscos`
--

DROP TABLE IF EXISTS `riscos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `riscos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` int(11) DEFAULT NULL,
  `estabelecimento` int(11) DEFAULT NULL,
  `descricao` varchar(45) DEFAULT NULL,
  `gravidade` int(11) DEFAULT NULL,
  `urgencia` int(11) DEFAULT NULL,
  `tendencia` int(11) DEFAULT NULL,
  `contencao` text DEFAULT NULL,
  `solucao` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sc_log`
--

DROP TABLE IF EXISTS `sc_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_log` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `inserted_date` datetime DEFAULT NULL,
  `username` varchar(90) NOT NULL,
  `application` varchar(255) NOT NULL,
  `creator` varchar(30) NOT NULL,
  `ip_user` varchar(255) NOT NULL,
  `action` varchar(30) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_apps`
--

DROP TABLE IF EXISTS `sec_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_apps` (
  `app_name` varchar(128) NOT NULL,
  `app_type` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`app_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_groups`
--

DROP TABLE IF EXISTS `sec_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_groups_apps`
--

DROP TABLE IF EXISTS `sec_groups_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_groups_apps` (
  `group_id` int(11) NOT NULL,
  `app_name` varchar(128) NOT NULL,
  `priv_access` varchar(1) DEFAULT NULL,
  `priv_insert` varchar(1) DEFAULT NULL,
  `priv_delete` varchar(1) DEFAULT NULL,
  `priv_update` varchar(1) DEFAULT NULL,
  `priv_export` varchar(1) DEFAULT NULL,
  `priv_print` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`group_id`,`app_name`),
  KEY `sec_groups_apps_ibfk_2` (`app_name`),
  CONSTRAINT `sec_groups_apps_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `sec_groups` (`group_id`) ON DELETE CASCADE,
  CONSTRAINT `sec_groups_apps_ibfk_2` FOREIGN KEY (`app_name`) REFERENCES `sec_apps` (`app_name`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_logged`
--

DROP TABLE IF EXISTS `sec_logged`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_logged` (
  `login` varchar(255) NOT NULL,
  `date_login` varchar(128) DEFAULT NULL,
  `sc_session` varchar(32) DEFAULT NULL,
  `ip` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_menu_dinamico`
--

DROP TABLE IF EXISTS `sec_menu_dinamico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_menu_dinamico` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pai` int(11) NOT NULL DEFAULT 0,
  `icone` varchar(255) DEFAULT NULL,
  `descricao` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `ordenacao` int(11) NOT NULL DEFAULT 0,
  `target` varchar(10) NOT NULL,
  `hint` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_pai_ordenacao` (`pai`,`ordenacao`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_settings`
--

DROP TABLE IF EXISTS `sec_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_settings` (
  `set_name` varchar(255) NOT NULL,
  `set_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`set_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_users`
--

DROP TABLE IF EXISTS `sec_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_users` (
  `login` varchar(255) NOT NULL,
  `pswd` varchar(255) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `active` varchar(1) DEFAULT NULL,
  `activation_code` varchar(32) DEFAULT NULL,
  `priv_admin` varchar(1) DEFAULT NULL,
  `mfa` varchar(255) DEFAULT NULL,
  `picture` longblob DEFAULT NULL,
  `empresa` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sec_users_groups`
--

DROP TABLE IF EXISTS `sec_users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sec_users_groups` (
  `login` varchar(255) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`login`,`group_id`),
  KEY `sec_users_groups_ibfk_2` (`group_id`),
  CONSTRAINT `sec_users_groups_ibfk_1` FOREIGN KEY (`login`) REFERENCES `sec_users` (`login`) ON DELETE CASCADE,
  CONSTRAINT `sec_users_groups_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `sec_groups` (`group_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `solic_controlador`
--

DROP TABLE IF EXISTS `solic_controlador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `solic_controlador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_solicitacao_controlador` datetime DEFAULT NULL,
  `controlador` int(11) DEFAULT NULL,
  `solicitante` varchar(99) DEFAULT NULL,
  `id_solicitante` varchar(45) DEFAULT NULL,
  `contato_email` varchar(99) DEFAULT NULL,
  `contato_telefonico` varchar(45) DEFAULT NULL,
  `descricao_solicitacao` varchar(99) DEFAULT NULL,
  `narrativa_solicitacao` text DEFAULT NULL,
  `base_solicitacao` int(11) DEFAULT NULL,
  `evidencia` longblob DEFAULT NULL,
  `caminho_evidencia` varchar(45) DEFAULT NULL,
  `parecer_dpo` int(11) DEFAULT NULL,
  `narrativa_parecer_dpo` text DEFAULT NULL,
  `data_parecer_dpo` datetime DEFAULT NULL,
  `doc_auxiliar` longblob DEFAULT NULL,
  `caminho_doc_auxiliar` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `protocolo` varchar(45) DEFAULT NULL,
  `autorizo_lgpd` int(11) DEFAULT NULL,
  `receber_contato` int(11) DEFAULT NULL,
  `relacao_controlador` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_01_01_idx` (`controlador`),
  KEY `fk_01_02_idx` (`base_solicitacao`),
  KEY `fk_01_03_idx` (`parecer_dpo`),
  KEY `fk_01_04_idx` (`status`),
  KEY `fk_01_05_idx` (`relacao_controlador`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Solicitacoes ao Controlador';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `status_geral`
--

DROP TABLE IF EXISTS `status_geral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `status_geral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_mapa_tabelas`
--

DROP TABLE IF EXISTS `sys_mapa_tabelas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_mapa_tabelas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  `narrativa` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tipo_tratamento_dados`
--

DROP TABLE IF EXISTS `tipo_tratamento_dados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_tratamento_dados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_dim_capitulo`
--

DROP TABLE IF EXISTS `tisax_dim_capitulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_dim_capitulo` (
  `capitulo_id` int(11) NOT NULL AUTO_INCREMENT,
  `capitulo_cod` varchar(50) NOT NULL,
  `capitulo_nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`capitulo_id`),
  UNIQUE KEY `uk_tisax_capitulo` (`capitulo_cod`,`capitulo_nome`),
  KEY `ix_tisax_capitulo_uni` (`capitulo_cod`,`capitulo_nome`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Dimensão Capítulo (VDA ISA): código (ex. 1.2) e nome do capítulo/tema de referência TISAX/VDA ISA.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_dim_controle`
--

DROP TABLE IF EXISTS `tisax_dim_controle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_dim_controle` (
  `controle_id` int(11) NOT NULL AUTO_INCREMENT,
  `controle_cod` varchar(50) NOT NULL,
  `controle_nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`controle_id`),
  UNIQUE KEY `uk_tisax_controle` (`controle_cod`,`controle_nome`),
  KEY `ix_tisax_controle_uni` (`controle_cod`,`controle_nome`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Dimensão Controle (VDA ISA2): código do controle (ex. 1.2.1) e sua denominação resumida.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_dim_eap`
--

DROP TABLE IF EXISTS `tisax_dim_eap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_dim_eap` (
  `eap_id` int(11) NOT NULL AUTO_INCREMENT,
  `eap_nome` varchar(255) NOT NULL,
  PRIMARY KEY (`eap_id`),
  UNIQUE KEY `uk_tisax_eap_nome` (`eap_nome`),
  KEY `ix_tisax_eap_nome` (`eap_nome`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Dimensão EAP: Estrutura Analítica do Projeto (nível macro de agrupamento dos itens do programa TISAX).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_dim_maturidade`
--

DROP TABLE IF EXISTS `tisax_dim_maturidade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_dim_maturidade` (
  `maturidade_id` int(11) NOT NULL AUTO_INCREMENT,
  `maturidade_cod` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`maturidade_id`),
  UNIQUE KEY `maturidade_cod` (`maturidade_cod`),
  KEY `ix_tisax_maturidade` (`maturidade_cod`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Dimensão Maturidade inicial: nível de maturidade informado na entrada (ex.: na, 1, 2, ...).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_dim_responsavel`
--

DROP TABLE IF EXISTS `tisax_dim_responsavel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_dim_responsavel` (
  `responsavel_id` int(11) NOT NULL AUTO_INCREMENT,
  `responsavel_nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`responsavel_id`),
  UNIQUE KEY `responsavel_nome` (`responsavel_nome`),
  KEY `ix_tisax_responsavel` (`responsavel_nome`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Dimensão Responsável: área/parte responsável pelo item (ex.: SGI, TI/SI, Compras, Comitê).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_documentation`
--

DROP TABLE IF EXISTS `tisax_documentation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_documentation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_schema` varchar(64) NOT NULL,
  `object_name` varchar(128) NOT NULL,
  `object_type` enum('TABLE','VIEW','PROCEDURE','FUNCTION','TRIGGER') NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_doc` (`object_schema`,`object_name`,`object_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_documentation_columns`
--

DROP TABLE IF EXISTS `tisax_documentation_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_documentation_columns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_schema` varchar(64) NOT NULL,
  `object_name` varchar(128) NOT NULL,
  `column_name` varchar(128) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_col` (`object_schema`,`object_name`,`column_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_fato_item`
--

DROP TABLE IF EXISTS `tisax_fato_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_fato_item` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `staging_row_id` bigint(20) DEFAULT NULL,
  `empresa` int(11) NOT NULL,
  `estabelecimento` int(11) NOT NULL,
  `eap_id` int(11) DEFAULT NULL,
  `capitulo_id` int(11) DEFAULT NULL,
  `controle_id` int(11) DEFAULT NULL,
  `subcontrole_id` int(11) DEFAULT NULL,
  `responsavel_id` int(11) DEFAULT NULL,
  `maturidade_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `objetivo` text DEFAULT NULL,
  `acao` text DEFAULT NULL,
  `comentarios` text DEFAULT NULL,
  `inicio_real_txt` varchar(50) DEFAULT NULL,
  `inicio_previsto_txt` varchar(50) DEFAULT NULL,
  `termino_previsto_txt` varchar(50) DEFAULT NULL,
  `termino_real_txt` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `staging_row_id` (`staging_row_id`),
  KEY `eap_id` (`eap_id`),
  KEY `capitulo_id` (`capitulo_id`),
  KEY `controle_id` (`controle_id`),
  KEY `subcontrole_id` (`subcontrole_id`),
  KEY `responsavel_id` (`responsavel_id`),
  KEY `maturidade_id` (`maturidade_id`),
  KEY `status_id` (`status_id`),
  CONSTRAINT `tisax_fato_item_ibfk_1` FOREIGN KEY (`eap_id`) REFERENCES `tisax_dim_eap` (`eap_id`),
  CONSTRAINT `tisax_fato_item_ibfk_2` FOREIGN KEY (`capitulo_id`) REFERENCES `tisax_dim_capitulo` (`capitulo_id`),
  CONSTRAINT `tisax_fato_item_ibfk_3` FOREIGN KEY (`controle_id`) REFERENCES `tisax_dim_controle` (`controle_id`),
  CONSTRAINT `tisax_fato_item_ibfk_4` FOREIGN KEY (`subcontrole_id`) REFERENCES `tisax_dim_subcontrole` (`subcontrole_id`),
  CONSTRAINT `tisax_fato_item_ibfk_5` FOREIGN KEY (`responsavel_id`) REFERENCES `tisax_dim_responsavel` (`responsavel_id`),
  CONSTRAINT `tisax_fato_item_ibfk_6` FOREIGN KEY (`maturidade_id`) REFERENCES `tisax_dim_maturidade` (`maturidade_id`),
  CONSTRAINT `tisax_fato_item_ibfk_7` FOREIGN KEY (`status_id`) REFERENCES `tisax_dim_status` (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Fato dos Itens TISAX: liga staging às dimensões (EAP, Capítulo, Controle, Subcontrole, Responsável, Maturidade, Status); guarda empresa/estabelecimento, objetivo/ação/comentários e datas como texto.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_object_doc_violations`
--

DROP TABLE IF EXISTS `tisax_object_doc_violations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_object_doc_violations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_schema` varchar(64) NOT NULL,
  `object_name` varchar(128) NOT NULL,
  `object_type` enum('TABLE','VIEW','TRIGGER','PROCEDURE') NOT NULL,
  `detected_at` datetime NOT NULL DEFAULT current_timestamp(),
  `status` enum('OPEN','ACK','IGNORED','FIXED') NOT NULL DEFAULT 'OPEN',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_violation` (`object_schema`,`object_name`,`object_type`,`detected_at`)
) ENGINE=InnoDB AUTO_INCREMENT=118949 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_object_docs`
--

DROP TABLE IF EXISTS `tisax_object_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_object_docs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `object_schema` varchar(64) NOT NULL,
  `object_name` varchar(128) NOT NULL,
  `object_type` enum('TABLE','VIEW','TRIGGER','PROCEDURE') NOT NULL,
  `comment_text` text NOT NULL,
  `created_by` varchar(128) NOT NULL DEFAULT current_user(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_obj` (`object_schema`,`object_name`,`object_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_staging`
--

DROP TABLE IF EXISTS `tisax_staging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_staging` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `empresa` int(11) DEFAULT NULL,
  `estabelecimento` int(11) DEFAULT NULL,
  `eap` int(11) DEFAULT NULL,
  `capitulo` text DEFAULT NULL,
  `norma_vda_isa` text DEFAULT NULL,
  `controle` text DEFAULT NULL,
  `norma_vda_isa2` text DEFAULT NULL,
  `sub_controle` text DEFAULT NULL,
  `objetivo` text DEFAULT NULL,
  `acao` text DEFAULT NULL,
  `comentarios` text DEFAULT NULL,
  `responsavel` text DEFAULT NULL,
  `maturidade_inicial` text DEFAULT NULL,
  `inicio_real` text DEFAULT NULL,
  `inicio_previsto` text DEFAULT NULL,
  `termino_previsto` text DEFAULT NULL,
  `termino_real` text DEFAULT NULL,
  `status` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tisax_staging_empresa_estab` (`empresa`,`estabelecimento`),
  KEY `ix_tisax_staging_status` (`status`(768)),
  KEY `ix_tisax_staging_emp_est` (`empresa`,`estabelecimento`)
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Staging (aterrissagem): dados brutos importados do CSV/planilhas para posterior tratamento e carga nas dimensões e fato.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tisax_view_docs`
--

DROP TABLE IF EXISTS `tisax_view_docs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tisax_view_docs` (
  `view_name` varchar(64) NOT NULL,
  `comentario` text DEFAULT NULL,
  PRIMARY KEY (`view_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `tisax_vw_atrasos`
--

DROP TABLE IF EXISTS `tisax_vw_atrasos`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_atrasos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_atrasos` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `controle`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `termino_real_date`,
  1 AS `status_norm`,
  1 AS `dias_atraso` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_backlog`
--

DROP TABLE IF EXISTS `tisax_vw_backlog`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_backlog`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_backlog` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `controle`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `termino_real_date`,
  1 AS `status_norm`,
  1 AS `dias_atraso`,
  1 AS `prioridade` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_base`
--

DROP TABLE IF EXISTS `tisax_vw_base`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_base`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_base` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `norma_vda_isa`,
  1 AS `controle`,
  1 AS `norma_vda_isa2`,
  1 AS `sub_controle`,
  1 AS `objetivo`,
  1 AS `acao`,
  1 AS `comentarios`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `status_norm`,
  1 AS `inicio_real_txt`,
  1 AS `inicio_previsto_txt`,
  1 AS `termino_previsto_txt`,
  1 AS `termino_real_txt`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `inicio_real_date`,
  1 AS `termino_real_date`,
  1 AS `concluido`,
  1 AS `em_atraso`,
  1 AS `sem_data_prevista`,
  1 AS `dias_atraso` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_calendario`
--

DROP TABLE IF EXISTS `tisax_vw_calendario`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_calendario`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_calendario` AS SELECT
 1 AS `ano`,
  1 AS `mes`,
  1 AS `ano_mes`,
  1 AS `total_previstos`,
  1 AS `concluidos_no_mes`,
  1 AS `pendentes_no_mes`,
  1 AS `atrasados_no_mes` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_doc_violations_latest`
--

DROP TABLE IF EXISTS `tisax_vw_doc_violations_latest`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_doc_violations_latest`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_doc_violations_latest` AS SELECT
 1 AS `id`,
  1 AS `object_schema`,
  1 AS `object_name`,
  1 AS `object_type`,
  1 AS `detected_at`,
  1 AS `status` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_documented_ok`
--

DROP TABLE IF EXISTS `tisax_vw_documented_ok`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_documented_ok`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_documented_ok` AS SELECT
 1 AS `object_schema`,
  1 AS `object_name`,
  1 AS `object_type`,
  1 AS `created_by`,
  1 AS `created_at` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_act`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_act`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_act`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_act` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `norma_vda_isa`,
  1 AS `controle`,
  1 AS `norma_vda_isa2`,
  1 AS `sub_controle`,
  1 AS `objetivo`,
  1 AS `acao`,
  1 AS `comentarios`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `status_norm`,
  1 AS `inicio_real_txt`,
  1 AS `inicio_previsto_txt`,
  1 AS `termino_previsto_txt`,
  1 AS `termino_real_txt`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `inicio_real_date`,
  1 AS `termino_real_date`,
  1 AS `concluido`,
  1 AS `em_atraso`,
  1 AS `sem_data_prevista`,
  1 AS `dias_atraso`,
  1 AS `pdca_fase`,
  1 AS `nao_iniciado`,
  1 AS `sem_prazo`,
  1 AS `dias_para_termino` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_calendario`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_calendario`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_calendario`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_calendario` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `pdca_fase`,
  1 AS `ano`,
  1 AS `mes`,
  1 AS `ano_mes`,
  1 AS `total` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_capitulo`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_capitulo`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_capitulo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_capitulo` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `capitulo`,
  1 AS `pdca_fase`,
  1 AS `qtd`,
  1 AS `atrasados`,
  1 AS `concluidos` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_check`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_check`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_check`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_check` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `norma_vda_isa`,
  1 AS `controle`,
  1 AS `norma_vda_isa2`,
  1 AS `sub_controle`,
  1 AS `objetivo`,
  1 AS `acao`,
  1 AS `comentarios`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `status_norm`,
  1 AS `inicio_real_txt`,
  1 AS `inicio_previsto_txt`,
  1 AS `termino_previsto_txt`,
  1 AS `termino_real_txt`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `inicio_real_date`,
  1 AS `termino_real_date`,
  1 AS `concluido`,
  1 AS `em_atraso`,
  1 AS `sem_data_prevista`,
  1 AS `dias_atraso`,
  1 AS `pdca_fase`,
  1 AS `nao_iniciado`,
  1 AS `sem_prazo`,
  1 AS `dias_para_termino`,
  1 AS `dias_desde_conclusao` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_do`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_do`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_do`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_do` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `norma_vda_isa`,
  1 AS `controle`,
  1 AS `norma_vda_isa2`,
  1 AS `sub_controle`,
  1 AS `objetivo`,
  1 AS `acao`,
  1 AS `comentarios`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `status_norm`,
  1 AS `inicio_real_txt`,
  1 AS `inicio_previsto_txt`,
  1 AS `termino_previsto_txt`,
  1 AS `termino_real_txt`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `inicio_real_date`,
  1 AS `termino_real_date`,
  1 AS `concluido`,
  1 AS `em_atraso`,
  1 AS `sem_data_prevista`,
  1 AS `dias_atraso`,
  1 AS `pdca_fase`,
  1 AS `nao_iniciado`,
  1 AS `sem_prazo`,
  1 AS `dias_para_termino` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_kpis`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_kpis`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_kpis`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_kpis` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `pdca_fase`,
  1 AS `qtd`,
  1 AS `qtd_atrasados`,
  1 AS `atraso_medio_dias`,
  1 AS `atraso_max_dias` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_map`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_map`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_map`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_map` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `norma_vda_isa`,
  1 AS `controle`,
  1 AS `norma_vda_isa2`,
  1 AS `sub_controle`,
  1 AS `objetivo`,
  1 AS `acao`,
  1 AS `comentarios`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `status_norm`,
  1 AS `inicio_real_txt`,
  1 AS `inicio_previsto_txt`,
  1 AS `termino_previsto_txt`,
  1 AS `termino_real_txt`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `inicio_real_date`,
  1 AS `termino_real_date`,
  1 AS `concluido`,
  1 AS `em_atraso`,
  1 AS `sem_data_prevista`,
  1 AS `dias_atraso`,
  1 AS `pdca_fase`,
  1 AS `nao_iniciado`,
  1 AS `sem_prazo`,
  1 AS `dias_para_termino` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_plan`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_plan`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_plan`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_plan` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `eap`,
  1 AS `capitulo`,
  1 AS `norma_vda_isa`,
  1 AS `controle`,
  1 AS `norma_vda_isa2`,
  1 AS `sub_controle`,
  1 AS `objetivo`,
  1 AS `acao`,
  1 AS `comentarios`,
  1 AS `responsavel`,
  1 AS `responsavel_norm`,
  1 AS `maturidade_inicial`,
  1 AS `status_norm`,
  1 AS `inicio_real_txt`,
  1 AS `inicio_previsto_txt`,
  1 AS `termino_previsto_txt`,
  1 AS `termino_real_txt`,
  1 AS `inicio_previsto_date`,
  1 AS `termino_previsto_date`,
  1 AS `inicio_real_date`,
  1 AS `termino_real_date`,
  1 AS `concluido`,
  1 AS `em_atraso`,
  1 AS `sem_data_prevista`,
  1 AS `dias_atraso`,
  1 AS `pdca_fase`,
  1 AS `nao_iniciado`,
  1 AS `sem_prazo`,
  1 AS `dias_para_termino` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_pdca_responsavel`
--

DROP TABLE IF EXISTS `tisax_vw_pdca_responsavel`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_responsavel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_pdca_responsavel` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `responsavel`,
  1 AS `pdca_fase`,
  1 AS `qtd`,
  1 AS `atrasados`,
  1 AS `concluidos`,
  1 AS `atraso_medio_dias` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_por_capitulo`
--

DROP TABLE IF EXISTS `tisax_vw_por_capitulo`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_por_capitulo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_por_capitulo` AS SELECT
 1 AS `capitulo`,
  1 AS `total`,
  1 AS `concluidos`,
  1 AS `atrasados`,
  1 AS `sem_data_prevista`,
  1 AS `atraso_medio_dias` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_por_responsavel`
--

DROP TABLE IF EXISTS `tisax_vw_por_responsavel`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_por_responsavel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_por_responsavel` AS SELECT
 1 AS `responsavel`,
  1 AS `total`,
  1 AS `concluidos`,
  1 AS `em_andamento`,
  1 AS `atrasados`,
  1 AS `sem_data_prevista`,
  1 AS `atraso_medio_dias`,
  1 AS `atraso_max_dias` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `tisax_vw_undocumented_objects`
--

DROP TABLE IF EXISTS `tisax_vw_undocumented_objects`;
/*!50001 DROP VIEW IF EXISTS `tisax_vw_undocumented_objects`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `tisax_vw_undocumented_objects` AS SELECT
 1 AS `object_schema`,
  1 AS `object_name`,
  1 AS `object_type` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `unidade_retencao`
--

DROP TABLE IF EXISTS `unidade_retencao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unidade_retencao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Unidade de Medida da Retencao de Dados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `vw_pdca_carga_por_responsavel`
--

DROP TABLE IF EXISTS `vw_pdca_carga_por_responsavel`;
/*!50001 DROP VIEW IF EXISTS `vw_pdca_carga_por_responsavel`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_pdca_carga_por_responsavel` AS SELECT
 1 AS `responsavel_id`,
  1 AS `responsavel_nome`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `abertas`,
  1 AS `em_andamento`,
  1 AS `concluidas`,
  1 AS `canceladas`,
  1 AS `total` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_pdca_eficacia`
--

DROP TABLE IF EXISTS `vw_pdca_eficacia`;
/*!50001 DROP VIEW IF EXISTS `vw_pdca_eficacia`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_pdca_eficacia` AS SELECT
 1 AS `ciclo_id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `risco_id`,
  1 AS `risco_descricao`,
  1 AS `gut_inicial`,
  1 AS `gut_alvo`,
  1 AS `gut_final`,
  1 AS `eficacia_pct` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_pdca_pipeline_etapa`
--

DROP TABLE IF EXISTS `vw_pdca_pipeline_etapa`;
/*!50001 DROP VIEW IF EXISTS `vw_pdca_pipeline_etapa`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_pdca_pipeline_etapa` AS SELECT
 1 AS `etapa`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `abertas`,
  1 AS `em_andamento`,
  1 AS `concluidas`,
  1 AS `total` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_pdca_portfolio`
--

DROP TABLE IF EXISTS `vw_pdca_portfolio`;
/*!50001 DROP VIEW IF EXISTS `vw_pdca_portfolio`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_pdca_portfolio` AS SELECT
 1 AS `ciclo_id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `risco_id`,
  1 AS `risco_descricao`,
  1 AS `titulo`,
  1 AS `ciclo_status`,
  1 AS `data_inicio`,
  1 AS `data_prevista_fim`,
  1 AS `gut_inicial`,
  1 AS `gut_alvo`,
  1 AS `gut_final`,
  1 AS `progresso_pct` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_pdca_tarefas_atrasadas`
--

DROP TABLE IF EXISTS `vw_pdca_tarefas_atrasadas`;
/*!50001 DROP VIEW IF EXISTS `vw_pdca_tarefas_atrasadas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_pdca_tarefas_atrasadas` AS SELECT
 1 AS `tarefa_id`,
  1 AS `ciclo_id`,
  1 AS `risco_id`,
  1 AS `risco_descricao`,
  1 AS `etapa`,
  1 AS `tarefa_titulo`,
  1 AS `responsavel_id`,
  1 AS `responsavel_nome`,
  1 AS `data_prevista`,
  1 AS `data_inicio`,
  1 AS `status`,
  1 AS `dias_atraso` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_auditoria_basica`
--

DROP TABLE IF EXISTS `vw_raci_auditoria_basica`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_auditoria_basica`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_auditoria_basica` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_nome`,
  1 AS `atividade_id`,
  1 AS `atividade_nome`,
  1 AS `role_id`,
  1 AS `role_nome`,
  1 AS `tipo`,
  1 AS `vinculo_created_at`,
  1 AS `atividade_created_at`,
  1 AS `atividade_updated_at` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_conflitos_RA`
--

DROP TABLE IF EXISTS `vw_raci_conflitos_RA`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_conflitos_RA`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_conflitos_RA` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_nome`,
  1 AS `atividade_id`,
  1 AS `atividade_nome`,
  1 AS `role_id`,
  1 AS `role_nome` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_controle_cardinalidade_A`
--

DROP TABLE IF EXISTS `vw_raci_controle_cardinalidade_A`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_controle_cardinalidade_A`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_controle_cardinalidade_A` AS SELECT
 1 AS `atividade_id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_nome`,
  1 AS `atividade_nome`,
  1 AS `qtd_A` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_controle_sem_CI`
--

DROP TABLE IF EXISTS `vw_raci_controle_sem_CI`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_controle_sem_CI`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_controle_sem_CI` AS SELECT
 1 AS `atividade_id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_nome`,
  1 AS `atividade_nome`,
  1 AS `qtd_C`,
  1 AS `qtd_I` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_controle_sem_R`
--

DROP TABLE IF EXISTS `vw_raci_controle_sem_R`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_controle_sem_R`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_controle_sem_R` AS SELECT
 1 AS `atividade_id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_nome`,
  1 AS `atividade_nome` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_matriz_atividade`
--

DROP TABLE IF EXISTS `vw_raci_matriz_atividade`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_matriz_atividade`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_matriz_atividade` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_nome`,
  1 AS `atividade_id`,
  1 AS `atividade_nome`,
  1 AS `responsaveis_R`,
  1 AS `aprovadores_A`,
  1 AS `consultados_C`,
  1 AS `informados_I` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_mov_expanded`
--

DROP TABLE IF EXISTS `vw_raci_mov_expanded`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_mov_expanded`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_mov_expanded` AS SELECT
 1 AS `atividade_id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_id`,
  1 AS `categoria_nome`,
  1 AS `atividade_nome`,
  1 AS `role_id`,
  1 AS `role_nome`,
  1 AS `tipo`,
  1 AS `vinculo_created_at`,
  1 AS `atividade_created_at`,
  1 AS `atividade_updated_at` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_resumo_categoria_area`
--

DROP TABLE IF EXISTS `vw_raci_resumo_categoria_area`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_resumo_categoria_area`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_resumo_categoria_area` AS SELECT
 1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `area`,
  1 AS `categoria_nome`,
  1 AS `atividades`,
  1 AS `atrib_R`,
  1 AS `atrib_A`,
  1 AS `atrib_C`,
  1 AS `atrib_I` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_raci_resumo_por_role`
--

DROP TABLE IF EXISTS `vw_raci_resumo_por_role`;
/*!50001 DROP VIEW IF EXISTS `vw_raci_resumo_por_role`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_raci_resumo_por_role` AS SELECT
 1 AS `role_id`,
  1 AS `role_nome`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `total_participacoes`,
  1 AS `qtd_R`,
  1 AS `qtd_A`,
  1 AS `qtd_C`,
  1 AS `qtd_I` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_risco_priorizacao`
--

DROP TABLE IF EXISTS `vw_risco_priorizacao`;
/*!50001 DROP VIEW IF EXISTS `vw_risco_priorizacao`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vw_risco_priorizacao` AS SELECT
 1 AS `id`,
  1 AS `empresa`,
  1 AS `estabelecimento`,
  1 AS `descricao`,
  1 AS `gravidade`,
  1 AS `urgencia`,
  1 AS `tendencia`,
  1 AS `gut_score`,
  1 AS `classe_gut` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'OpenRiskManager'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `tisax_ev_doc_audit` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`%`*/ /*!50106 EVENT `tisax_ev_doc_audit` ON SCHEDULE EVERY 5 MINUTE STARTS '2025-08-24 21:28:45' ON COMPLETION PRESERVE ENABLE DO BEGIN
  INSERT IGNORE INTO tisax_object_doc_violations (object_schema, object_name, object_type)
  SELECT object_schema, object_name, object_type
  FROM tisax_vw_undocumented_objects;
END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'OpenRiskManager'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tisax_create_object_auto_doc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `tisax_create_object_auto_doc`(
  IN p_object_type ENUM('TABLE','VIEW','PROCEDURE','FUNCTION','TRIGGER'),
  IN p_object_name VARCHAR(128),
  IN p_create_sql  LONGTEXT,
  IN p_fallback_description TEXT  -- usado só se o objeto não suportar COMMENT (ex.: TRIGGER) ou se o COMMENT vier vazio
)
BEGIN
  DECLARE v_schema VARCHAR(64) DEFAULT DATABASE();
  DECLARE v_desc   TEXT DEFAULT NULL;

  /* executa o DDL do objeto */
  SET @ddl := p_create_sql;
  PREPARE stmt FROM @ddl;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;

  /* coleta o comentário do objeto recém-criado */
  IF p_object_type IN ('TABLE','VIEW') THEN
    SELECT t.TABLE_COMMENT
      INTO v_desc
      FROM information_schema.TABLES t
     WHERE t.TABLE_SCHEMA = v_schema
       AND t.TABLE_NAME   = p_object_name
     LIMIT 1;

    /* registra/atualiza documentação do objeto */
    INSERT INTO tisax_documentation(object_schema, object_name, object_type, description)
    VALUES (v_schema, p_object_name, p_object_type, NULLIF(v_desc,''))
    ON DUPLICATE KEY UPDATE
      description = VALUES(description),
      updated_at  = CURRENT_TIMESTAMP;

    /* (re)popular documentação de colunas com base em COLUMN_COMMENT */
    /* remove colunas antigas desse objeto para repopular */
    DELETE FROM tisax_documentation_columns
     WHERE object_schema = v_schema
       AND object_name   = p_object_name;

    INSERT INTO tisax_documentation_columns(object_schema, object_name, column_name, description)
    SELECT c.TABLE_SCHEMA, c.TABLE_NAME, c.COLUMN_NAME, NULLIF(c.COLUMN_COMMENT,'')
      FROM information_schema.COLUMNS c
     WHERE c.TABLE_SCHEMA = v_schema
       AND c.TABLE_NAME   = p_object_name;

  ELSEIF p_object_type IN ('PROCEDURE','FUNCTION') THEN
    SELECT r.ROUTINE_COMMENT
      INTO v_desc
      FROM information_schema.ROUTINES r
     WHERE r.ROUTINE_SCHEMA = v_schema
       AND r.ROUTINE_NAME   = p_object_name
       AND r.ROUTINE_TYPE   = p_object_type
     LIMIT 1;

    INSERT INTO tisax_documentation(object_schema, object_name, object_type, description)
    VALUES (v_schema, p_object_name, p_object_type, NULLIF(v_desc,''))
    ON DUPLICATE KEY UPDATE
      description = VALUES(description),
      updated_at  = CURRENT_TIMESTAMP;

  ELSEIF p_object_type = 'TRIGGER' THEN
    /* TRIGGER não tem COMMENT nativo; usa fallback (se fornecido) */
    SET v_desc = NULLIF(p_fallback_description, '');
    INSERT INTO tisax_documentation(object_schema, object_name, object_type, description)
    VALUES (v_schema, p_object_name, p_object_type, v_desc)
    ON DUPLICATE KEY UPDATE
      description = VALUES(description),
      updated_at  = CURRENT_TIMESTAMP;
  END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tisax_create_table_with_doc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `tisax_create_table_with_doc`(
  IN p_object_name  VARCHAR(128),
  IN p_comment_text TEXT,
  IN p_create_sql   LONGTEXT   -- o DDL completo: CREATE TABLE ...
)
BEGIN
  DECLARE v_schema VARCHAR(64) DEFAULT DATABASE();
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
  BEGIN
    -- Se falhar o DDL, remova a doc criada para não “sujar”
    DELETE FROM tisax_object_docs
     WHERE object_schema = v_schema
       AND object_name   = p_object_name
       AND object_type   = 'TABLE';
    RESIGNAL;
  END;

  -- Registra a documentação primeiro
  CALL tisax_require_doc(v_schema, p_object_name, 'TABLE', p_comment_text);

  -- Executa o DDL
  SET @sql := p_create_sql;
  PREPARE stmt FROM @sql;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tisax_create_view_with_doc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `tisax_create_view_with_doc`(
  IN p_object_name  VARCHAR(128),
  IN p_comment_text TEXT,
  IN p_create_sql   LONGTEXT   -- o DDL completo: CREATE OR REPLACE VIEW ...
)
BEGIN
  DECLARE v_schema VARCHAR(64) DEFAULT DATABASE();
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
  BEGIN
    DELETE FROM tisax_object_docs
     WHERE object_schema = v_schema
       AND object_name   = p_object_name
       AND object_type   = 'VIEW';
    RESIGNAL;
  END;

  CALL tisax_require_doc(v_schema, p_object_name, 'VIEW', p_comment_text);

  SET @sql := p_create_sql;
  PREPARE stmt FROM @sql;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `tisax_require_doc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `tisax_require_doc`(
  IN p_object_schema VARCHAR(64),
  IN p_object_name   VARCHAR(128),
  IN p_object_type   ENUM('TABLE','VIEW','TRIGGER','PROCEDURE'),
  IN p_comment_text  TEXT
)
BEGIN
  INSERT INTO tisax_object_docs (object_schema, object_name, object_type, comment_text)
  VALUES (p_object_schema, p_object_name, p_object_type, p_comment_text)
  ON DUPLICATE KEY UPDATE
    comment_text = VALUES(comment_text),
    created_by   = CURRENT_USER(),
    created_at   = CURRENT_TIMESTAMP;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `tisax_vw_atrasos`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_atrasos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_atrasos` AS select `tisax_vw_base`.`id` AS `id`,`tisax_vw_base`.`empresa` AS `empresa`,`tisax_vw_base`.`estabelecimento` AS `estabelecimento`,`tisax_vw_base`.`eap` AS `eap`,`tisax_vw_base`.`capitulo` AS `capitulo`,`tisax_vw_base`.`controle` AS `controle`,`tisax_vw_base`.`responsavel` AS `responsavel`,`tisax_vw_base`.`responsavel_norm` AS `responsavel_norm`,`tisax_vw_base`.`maturidade_inicial` AS `maturidade_inicial`,`tisax_vw_base`.`inicio_previsto_date` AS `inicio_previsto_date`,`tisax_vw_base`.`termino_previsto_date` AS `termino_previsto_date`,`tisax_vw_base`.`termino_real_date` AS `termino_real_date`,`tisax_vw_base`.`status_norm` AS `status_norm`,`tisax_vw_base`.`dias_atraso` AS `dias_atraso` from `tisax_vw_base` where `tisax_vw_base`.`em_atraso` = 1 order by `tisax_vw_base`.`dias_atraso` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_backlog`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_backlog`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_backlog` AS select `tisax_vw_base`.`id` AS `id`,`tisax_vw_base`.`empresa` AS `empresa`,`tisax_vw_base`.`estabelecimento` AS `estabelecimento`,`tisax_vw_base`.`eap` AS `eap`,`tisax_vw_base`.`capitulo` AS `capitulo`,`tisax_vw_base`.`controle` AS `controle`,`tisax_vw_base`.`responsavel` AS `responsavel`,`tisax_vw_base`.`responsavel_norm` AS `responsavel_norm`,`tisax_vw_base`.`maturidade_inicial` AS `maturidade_inicial`,`tisax_vw_base`.`inicio_previsto_date` AS `inicio_previsto_date`,`tisax_vw_base`.`termino_previsto_date` AS `termino_previsto_date`,`tisax_vw_base`.`termino_real_date` AS `termino_real_date`,`tisax_vw_base`.`status_norm` AS `status_norm`,`tisax_vw_base`.`dias_atraso` AS `dias_atraso`,case when `tisax_vw_base`.`concluido` = 1 then 4 when `tisax_vw_base`.`em_atraso` = 1 then 1 when `tisax_vw_base`.`sem_data_prevista` = 1 then 2 else 3 end AS `prioridade` from `tisax_vw_base` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_base`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_base`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_base` AS select `s`.`id` AS `id`,`s`.`empresa` AS `empresa`,`s`.`estabelecimento` AS `estabelecimento`,`s`.`eap` AS `eap`,trim(`s`.`capitulo`) AS `capitulo`,trim(`s`.`norma_vda_isa`) AS `norma_vda_isa`,trim(`s`.`controle`) AS `controle`,trim(`s`.`norma_vda_isa2`) AS `norma_vda_isa2`,trim(`s`.`sub_controle`) AS `sub_controle`,trim(`s`.`objetivo`) AS `objetivo`,trim(`s`.`acao`) AS `acao`,trim(`s`.`comentarios`) AS `comentarios`,trim(`s`.`responsavel`) AS `responsavel`,ucase(trim(`s`.`responsavel`)) AS `responsavel_norm`,trim(`s`.`maturidade_inicial`) AS `maturidade_inicial`,lcase(trim(`s`.`status`)) AS `status_norm`,trim(`s`.`inicio_real`) AS `inicio_real_txt`,trim(`s`.`inicio_previsto`) AS `inicio_previsto_txt`,trim(`s`.`termino_previsto`) AS `termino_previsto_txt`,trim(`s`.`termino_real`) AS `termino_real_txt`,coalesce(str_to_date(nullif(trim(`s`.`inicio_previsto`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`inicio_previsto`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`inicio_previsto`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`inicio_previsto`),''),'%d.%m.%Y')) AS `inicio_previsto_date`,coalesce(str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d.%m.%Y')) AS `termino_previsto_date`,coalesce(str_to_date(nullif(trim(`s`.`inicio_real`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`inicio_real`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`inicio_real`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`inicio_real`),''),'%d.%m.%Y')) AS `inicio_real_date`,coalesce(str_to_date(nullif(trim(`s`.`termino_real`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d.%m.%Y')) AS `termino_real_date`,case when coalesce(str_to_date(nullif(trim(`s`.`termino_real`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d.%m.%Y')) is not null then 1 else 0 end AS `concluido`,case when coalesce(str_to_date(nullif(trim(`s`.`termino_real`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d.%m.%Y')) is null and coalesce(str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d.%m.%Y')) < curdate() then 1 else 0 end AS `em_atraso`,case when coalesce(str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d.%m.%Y')) is null then 1 else 0 end AS `sem_data_prevista`,case when coalesce(str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d.%m.%Y')) is null then NULL when coalesce(str_to_date(nullif(trim(`s`.`termino_real`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d.%m.%Y')) is null then greatest(to_days(curdate()) - to_days(coalesce(str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d.%m.%Y'))),0) else greatest(to_days(coalesce(str_to_date(nullif(trim(`s`.`termino_real`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_real`),''),'%d.%m.%Y'))) - to_days(coalesce(str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%Y-%m-%d'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d/%m/%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d-%m-%Y'),str_to_date(nullif(trim(`s`.`termino_previsto`),''),'%d.%m.%Y'))),0) end AS `dias_atraso` from `tisax_staging` `s` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_calendario`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_calendario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_calendario` AS select year(`tisax_vw_base`.`termino_previsto_date`) AS `ano`,month(`tisax_vw_base`.`termino_previsto_date`) AS `mes`,date_format(`tisax_vw_base`.`termino_previsto_date`,'%Y-%m') AS `ano_mes`,count(0) AS `total_previstos`,sum(case when `tisax_vw_base`.`concluido` = 1 then 1 else 0 end) AS `concluidos_no_mes`,sum(case when `tisax_vw_base`.`concluido` = 0 then 1 else 0 end) AS `pendentes_no_mes`,sum(case when `tisax_vw_base`.`em_atraso` = 1 then 1 else 0 end) AS `atrasados_no_mes` from `tisax_vw_base` where `tisax_vw_base`.`termino_previsto_date` is not null group by year(`tisax_vw_base`.`termino_previsto_date`),month(`tisax_vw_base`.`termino_previsto_date`) order by year(`tisax_vw_base`.`termino_previsto_date`),month(`tisax_vw_base`.`termino_previsto_date`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_doc_violations_latest`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_doc_violations_latest`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_doc_violations_latest` AS select `tisax_object_doc_violations`.`id` AS `id`,`tisax_object_doc_violations`.`object_schema` AS `object_schema`,`tisax_object_doc_violations`.`object_name` AS `object_name`,`tisax_object_doc_violations`.`object_type` AS `object_type`,`tisax_object_doc_violations`.`detected_at` AS `detected_at`,`tisax_object_doc_violations`.`status` AS `status` from `tisax_object_doc_violations` where `tisax_object_doc_violations`.`detected_at` >= current_timestamp() - interval 1 day order by `tisax_object_doc_violations`.`detected_at` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_documented_ok`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_documented_ok`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_documented_ok` AS select `d`.`object_schema` AS `object_schema`,`d`.`object_name` AS `object_name`,`d`.`object_type` AS `object_type`,`d`.`created_by` AS `created_by`,`d`.`created_at` AS `created_at` from `OpenRiskManager`.`tisax_object_docs` `d` where !exists(select 1 from `OpenRiskManager`.`tisax_vw_undocumented_objects` `u` where `u`.`object_schema` = `d`.`object_schema` and `u`.`object_name` = `d`.`object_name` and `u`.`object_type` = `d`.`object_type` limit 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_act`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_act`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_act` AS select `tisax_vw_pdca_map`.`id` AS `id`,`tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`eap` AS `eap`,`tisax_vw_pdca_map`.`capitulo` AS `capitulo`,`tisax_vw_pdca_map`.`norma_vda_isa` AS `norma_vda_isa`,`tisax_vw_pdca_map`.`controle` AS `controle`,`tisax_vw_pdca_map`.`norma_vda_isa2` AS `norma_vda_isa2`,`tisax_vw_pdca_map`.`sub_controle` AS `sub_controle`,`tisax_vw_pdca_map`.`objetivo` AS `objetivo`,`tisax_vw_pdca_map`.`acao` AS `acao`,`tisax_vw_pdca_map`.`comentarios` AS `comentarios`,`tisax_vw_pdca_map`.`responsavel` AS `responsavel`,`tisax_vw_pdca_map`.`responsavel_norm` AS `responsavel_norm`,`tisax_vw_pdca_map`.`maturidade_inicial` AS `maturidade_inicial`,`tisax_vw_pdca_map`.`status_norm` AS `status_norm`,`tisax_vw_pdca_map`.`inicio_real_txt` AS `inicio_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_txt` AS `inicio_previsto_txt`,`tisax_vw_pdca_map`.`termino_previsto_txt` AS `termino_previsto_txt`,`tisax_vw_pdca_map`.`termino_real_txt` AS `termino_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_date` AS `inicio_previsto_date`,`tisax_vw_pdca_map`.`termino_previsto_date` AS `termino_previsto_date`,`tisax_vw_pdca_map`.`inicio_real_date` AS `inicio_real_date`,`tisax_vw_pdca_map`.`termino_real_date` AS `termino_real_date`,`tisax_vw_pdca_map`.`concluido` AS `concluido`,`tisax_vw_pdca_map`.`em_atraso` AS `em_atraso`,`tisax_vw_pdca_map`.`sem_data_prevista` AS `sem_data_prevista`,`tisax_vw_pdca_map`.`dias_atraso` AS `dias_atraso`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,`tisax_vw_pdca_map`.`nao_iniciado` AS `nao_iniciado`,`tisax_vw_pdca_map`.`sem_prazo` AS `sem_prazo`,`tisax_vw_pdca_map`.`dias_para_termino` AS `dias_para_termino` from `tisax_vw_pdca_map` where `tisax_vw_pdca_map`.`pdca_fase` = 'A' order by `tisax_vw_pdca_map`.`dias_atraso` desc,`tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_calendario`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_calendario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_calendario` AS select `tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,year(coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`)) AS `ano`,month(coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`)) AS `mes`,date_format(coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`),'%Y-%m') AS `ano_mes`,count(0) AS `total` from `tisax_vw_pdca_map` where coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`) is not null group by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,`tisax_vw_pdca_map`.`pdca_fase`,year(coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`)),month(coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`)) order by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,year(coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`)),month(coalesce(`tisax_vw_pdca_map`.`termino_previsto_date`,`tisax_vw_pdca_map`.`termino_real_date`)),field(`tisax_vw_pdca_map`.`pdca_fase`,'A','D','P','C') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_capitulo`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_capitulo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_capitulo` AS select `tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`capitulo` AS `capitulo`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,count(0) AS `qtd`,sum(case when `tisax_vw_pdca_map`.`em_atraso` = 1 then 1 else 0 end) AS `atrasados`,sum(case when `tisax_vw_pdca_map`.`concluido` = 1 then 1 else 0 end) AS `concluidos` from `tisax_vw_pdca_map` group by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,`tisax_vw_pdca_map`.`capitulo`,`tisax_vw_pdca_map`.`pdca_fase` order by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,`tisax_vw_pdca_map`.`capitulo`,field(`tisax_vw_pdca_map`.`pdca_fase`,'A','D','P','C') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_check`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_check`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_check` AS select `tisax_vw_pdca_map`.`id` AS `id`,`tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`eap` AS `eap`,`tisax_vw_pdca_map`.`capitulo` AS `capitulo`,`tisax_vw_pdca_map`.`norma_vda_isa` AS `norma_vda_isa`,`tisax_vw_pdca_map`.`controle` AS `controle`,`tisax_vw_pdca_map`.`norma_vda_isa2` AS `norma_vda_isa2`,`tisax_vw_pdca_map`.`sub_controle` AS `sub_controle`,`tisax_vw_pdca_map`.`objetivo` AS `objetivo`,`tisax_vw_pdca_map`.`acao` AS `acao`,`tisax_vw_pdca_map`.`comentarios` AS `comentarios`,`tisax_vw_pdca_map`.`responsavel` AS `responsavel`,`tisax_vw_pdca_map`.`responsavel_norm` AS `responsavel_norm`,`tisax_vw_pdca_map`.`maturidade_inicial` AS `maturidade_inicial`,`tisax_vw_pdca_map`.`status_norm` AS `status_norm`,`tisax_vw_pdca_map`.`inicio_real_txt` AS `inicio_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_txt` AS `inicio_previsto_txt`,`tisax_vw_pdca_map`.`termino_previsto_txt` AS `termino_previsto_txt`,`tisax_vw_pdca_map`.`termino_real_txt` AS `termino_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_date` AS `inicio_previsto_date`,`tisax_vw_pdca_map`.`termino_previsto_date` AS `termino_previsto_date`,`tisax_vw_pdca_map`.`inicio_real_date` AS `inicio_real_date`,`tisax_vw_pdca_map`.`termino_real_date` AS `termino_real_date`,`tisax_vw_pdca_map`.`concluido` AS `concluido`,`tisax_vw_pdca_map`.`em_atraso` AS `em_atraso`,`tisax_vw_pdca_map`.`sem_data_prevista` AS `sem_data_prevista`,`tisax_vw_pdca_map`.`dias_atraso` AS `dias_atraso`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,`tisax_vw_pdca_map`.`nao_iniciado` AS `nao_iniciado`,`tisax_vw_pdca_map`.`sem_prazo` AS `sem_prazo`,`tisax_vw_pdca_map`.`dias_para_termino` AS `dias_para_termino`,to_days(curdate()) - to_days(`tisax_vw_pdca_map`.`termino_real_date`) AS `dias_desde_conclusao` from `tisax_vw_pdca_map` where `tisax_vw_pdca_map`.`pdca_fase` = 'C' order by `tisax_vw_pdca_map`.`termino_real_date` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_do`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_do`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_do` AS select `tisax_vw_pdca_map`.`id` AS `id`,`tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`eap` AS `eap`,`tisax_vw_pdca_map`.`capitulo` AS `capitulo`,`tisax_vw_pdca_map`.`norma_vda_isa` AS `norma_vda_isa`,`tisax_vw_pdca_map`.`controle` AS `controle`,`tisax_vw_pdca_map`.`norma_vda_isa2` AS `norma_vda_isa2`,`tisax_vw_pdca_map`.`sub_controle` AS `sub_controle`,`tisax_vw_pdca_map`.`objetivo` AS `objetivo`,`tisax_vw_pdca_map`.`acao` AS `acao`,`tisax_vw_pdca_map`.`comentarios` AS `comentarios`,`tisax_vw_pdca_map`.`responsavel` AS `responsavel`,`tisax_vw_pdca_map`.`responsavel_norm` AS `responsavel_norm`,`tisax_vw_pdca_map`.`maturidade_inicial` AS `maturidade_inicial`,`tisax_vw_pdca_map`.`status_norm` AS `status_norm`,`tisax_vw_pdca_map`.`inicio_real_txt` AS `inicio_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_txt` AS `inicio_previsto_txt`,`tisax_vw_pdca_map`.`termino_previsto_txt` AS `termino_previsto_txt`,`tisax_vw_pdca_map`.`termino_real_txt` AS `termino_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_date` AS `inicio_previsto_date`,`tisax_vw_pdca_map`.`termino_previsto_date` AS `termino_previsto_date`,`tisax_vw_pdca_map`.`inicio_real_date` AS `inicio_real_date`,`tisax_vw_pdca_map`.`termino_real_date` AS `termino_real_date`,`tisax_vw_pdca_map`.`concluido` AS `concluido`,`tisax_vw_pdca_map`.`em_atraso` AS `em_atraso`,`tisax_vw_pdca_map`.`sem_data_prevista` AS `sem_data_prevista`,`tisax_vw_pdca_map`.`dias_atraso` AS `dias_atraso`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,`tisax_vw_pdca_map`.`nao_iniciado` AS `nao_iniciado`,`tisax_vw_pdca_map`.`sem_prazo` AS `sem_prazo`,`tisax_vw_pdca_map`.`dias_para_termino` AS `dias_para_termino` from `tisax_vw_pdca_map` where `tisax_vw_pdca_map`.`pdca_fase` = 'D' order by `tisax_vw_pdca_map`.`dias_para_termino`,`tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_kpis`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_kpis`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_kpis` AS select `tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,count(0) AS `qtd`,sum(case when `tisax_vw_pdca_map`.`em_atraso` = 1 then 1 else 0 end) AS `qtd_atrasados`,avg(nullif(`tisax_vw_pdca_map`.`dias_atraso`,0)) AS `atraso_medio_dias`,max(`tisax_vw_pdca_map`.`dias_atraso`) AS `atraso_max_dias` from `tisax_vw_pdca_map` group by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,`tisax_vw_pdca_map`.`pdca_fase` order by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,field(`tisax_vw_pdca_map`.`pdca_fase`,'A','D','P','C') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_map`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_map`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_map` AS select `b`.`id` AS `id`,`b`.`empresa` AS `empresa`,`b`.`estabelecimento` AS `estabelecimento`,`b`.`eap` AS `eap`,`b`.`capitulo` AS `capitulo`,`b`.`norma_vda_isa` AS `norma_vda_isa`,`b`.`controle` AS `controle`,`b`.`norma_vda_isa2` AS `norma_vda_isa2`,`b`.`sub_controle` AS `sub_controle`,`b`.`objetivo` AS `objetivo`,`b`.`acao` AS `acao`,`b`.`comentarios` AS `comentarios`,`b`.`responsavel` AS `responsavel`,`b`.`responsavel_norm` AS `responsavel_norm`,`b`.`maturidade_inicial` AS `maturidade_inicial`,`b`.`status_norm` AS `status_norm`,`b`.`inicio_real_txt` AS `inicio_real_txt`,`b`.`inicio_previsto_txt` AS `inicio_previsto_txt`,`b`.`termino_previsto_txt` AS `termino_previsto_txt`,`b`.`termino_real_txt` AS `termino_real_txt`,`b`.`inicio_previsto_date` AS `inicio_previsto_date`,`b`.`termino_previsto_date` AS `termino_previsto_date`,`b`.`inicio_real_date` AS `inicio_real_date`,`b`.`termino_real_date` AS `termino_real_date`,`b`.`concluido` AS `concluido`,`b`.`em_atraso` AS `em_atraso`,`b`.`sem_data_prevista` AS `sem_data_prevista`,`b`.`dias_atraso` AS `dias_atraso`,case when `b`.`em_atraso` = 1 then 'A' when `b`.`concluido` = 1 then 'C' when `b`.`inicio_real_date` is not null and `b`.`termino_real_date` is null then 'D' when `b`.`inicio_previsto_date` is not null and `b`.`inicio_real_date` is null then 'P' else 'P' end AS `pdca_fase`,`b`.`inicio_real_date` is null AS `nao_iniciado`,`b`.`termino_previsto_date` is null AS `sem_prazo`,case when `b`.`concluido` = 1 or `b`.`termino_previsto_date` is null then NULL else to_days(`b`.`termino_previsto_date`) - to_days(curdate()) end AS `dias_para_termino` from `tisax_vw_base` `b` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_plan`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_plan`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_plan` AS select `tisax_vw_pdca_map`.`id` AS `id`,`tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`eap` AS `eap`,`tisax_vw_pdca_map`.`capitulo` AS `capitulo`,`tisax_vw_pdca_map`.`norma_vda_isa` AS `norma_vda_isa`,`tisax_vw_pdca_map`.`controle` AS `controle`,`tisax_vw_pdca_map`.`norma_vda_isa2` AS `norma_vda_isa2`,`tisax_vw_pdca_map`.`sub_controle` AS `sub_controle`,`tisax_vw_pdca_map`.`objetivo` AS `objetivo`,`tisax_vw_pdca_map`.`acao` AS `acao`,`tisax_vw_pdca_map`.`comentarios` AS `comentarios`,`tisax_vw_pdca_map`.`responsavel` AS `responsavel`,`tisax_vw_pdca_map`.`responsavel_norm` AS `responsavel_norm`,`tisax_vw_pdca_map`.`maturidade_inicial` AS `maturidade_inicial`,`tisax_vw_pdca_map`.`status_norm` AS `status_norm`,`tisax_vw_pdca_map`.`inicio_real_txt` AS `inicio_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_txt` AS `inicio_previsto_txt`,`tisax_vw_pdca_map`.`termino_previsto_txt` AS `termino_previsto_txt`,`tisax_vw_pdca_map`.`termino_real_txt` AS `termino_real_txt`,`tisax_vw_pdca_map`.`inicio_previsto_date` AS `inicio_previsto_date`,`tisax_vw_pdca_map`.`termino_previsto_date` AS `termino_previsto_date`,`tisax_vw_pdca_map`.`inicio_real_date` AS `inicio_real_date`,`tisax_vw_pdca_map`.`termino_real_date` AS `termino_real_date`,`tisax_vw_pdca_map`.`concluido` AS `concluido`,`tisax_vw_pdca_map`.`em_atraso` AS `em_atraso`,`tisax_vw_pdca_map`.`sem_data_prevista` AS `sem_data_prevista`,`tisax_vw_pdca_map`.`dias_atraso` AS `dias_atraso`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,`tisax_vw_pdca_map`.`nao_iniciado` AS `nao_iniciado`,`tisax_vw_pdca_map`.`sem_prazo` AS `sem_prazo`,`tisax_vw_pdca_map`.`dias_para_termino` AS `dias_para_termino` from `tisax_vw_pdca_map` where `tisax_vw_pdca_map`.`pdca_fase` = 'P' order by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,`tisax_vw_pdca_map`.`termino_previsto_date` is null,`tisax_vw_pdca_map`.`termino_previsto_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_pdca_responsavel`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_pdca_responsavel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_pdca_responsavel` AS select `tisax_vw_pdca_map`.`empresa` AS `empresa`,`tisax_vw_pdca_map`.`estabelecimento` AS `estabelecimento`,`tisax_vw_pdca_map`.`responsavel_norm` AS `responsavel`,`tisax_vw_pdca_map`.`pdca_fase` AS `pdca_fase`,count(0) AS `qtd`,sum(case when `tisax_vw_pdca_map`.`em_atraso` = 1 then 1 else 0 end) AS `atrasados`,sum(case when `tisax_vw_pdca_map`.`concluido` = 1 then 1 else 0 end) AS `concluidos`,avg(nullif(`tisax_vw_pdca_map`.`dias_atraso`,0)) AS `atraso_medio_dias` from `tisax_vw_pdca_map` group by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,`tisax_vw_pdca_map`.`responsavel_norm`,`tisax_vw_pdca_map`.`pdca_fase` order by `tisax_vw_pdca_map`.`empresa`,`tisax_vw_pdca_map`.`estabelecimento`,`tisax_vw_pdca_map`.`responsavel_norm`,field(`tisax_vw_pdca_map`.`pdca_fase`,'A','D','P','C') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_por_capitulo`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_por_capitulo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_por_capitulo` AS select `tisax_vw_base`.`capitulo` AS `capitulo`,count(0) AS `total`,sum(case when `tisax_vw_base`.`concluido` = 1 then 1 else 0 end) AS `concluidos`,sum(case when `tisax_vw_base`.`em_atraso` = 1 then 1 else 0 end) AS `atrasados`,sum(case when `tisax_vw_base`.`sem_data_prevista` = 1 then 1 else 0 end) AS `sem_data_prevista`,avg(nullif(`tisax_vw_base`.`dias_atraso`,0)) AS `atraso_medio_dias` from `tisax_vw_base` group by `tisax_vw_base`.`capitulo` order by sum(case when `tisax_vw_base`.`em_atraso` = 1 then 1 else 0 end) desc,avg(nullif(`tisax_vw_base`.`dias_atraso`,0)) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_por_responsavel`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_por_responsavel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_por_responsavel` AS select `tisax_vw_base`.`responsavel_norm` AS `responsavel`,count(0) AS `total`,sum(case when `tisax_vw_base`.`concluido` = 1 then 1 else 0 end) AS `concluidos`,sum(case when `tisax_vw_base`.`concluido` = 0 then 1 else 0 end) AS `em_andamento`,sum(case when `tisax_vw_base`.`em_atraso` = 1 then 1 else 0 end) AS `atrasados`,sum(case when `tisax_vw_base`.`sem_data_prevista` = 1 then 1 else 0 end) AS `sem_data_prevista`,avg(nullif(`tisax_vw_base`.`dias_atraso`,0)) AS `atraso_medio_dias`,max(`tisax_vw_base`.`dias_atraso`) AS `atraso_max_dias` from `tisax_vw_base` group by `tisax_vw_base`.`responsavel_norm` order by sum(case when `tisax_vw_base`.`em_atraso` = 1 then 1 else 0 end) desc,sum(case when `tisax_vw_base`.`concluido` = 0 then 1 else 0 end) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tisax_vw_undocumented_objects`
--

/*!50001 DROP VIEW IF EXISTS `tisax_vw_undocumented_objects`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `tisax_vw_undocumented_objects` AS select `t`.`TABLE_SCHEMA` AS `object_schema`,`t`.`TABLE_NAME` AS `object_name`,'TABLE' AS `object_type` from (`information_schema`.`TABLES` `t` left join `OpenRiskManager`.`tisax_object_docs` `d` on(`d`.`object_schema` = `t`.`TABLE_SCHEMA` and `d`.`object_name` = `t`.`TABLE_NAME` and `d`.`object_type` = 'TABLE')) where `t`.`TABLE_SCHEMA` = database() and `t`.`TABLE_TYPE` = 'BASE TABLE' and `d`.`id` is null union all select `v`.`TABLE_SCHEMA` AS `TABLE_SCHEMA`,`v`.`TABLE_NAME` AS `TABLE_NAME`,'VIEW' AS `VIEW` from (`information_schema`.`VIEWS` `v` left join `OpenRiskManager`.`tisax_object_docs` `d` on(`d`.`object_schema` = `v`.`TABLE_SCHEMA` and `d`.`object_name` = `v`.`TABLE_NAME` and `d`.`object_type` = 'VIEW')) where `v`.`TABLE_SCHEMA` = database() and `d`.`id` is null union all select `tr`.`TRIGGER_SCHEMA` AS `TRIGGER_SCHEMA`,`tr`.`TRIGGER_NAME` AS `TRIGGER_NAME`,'TRIGGER' AS `TRIGGER` from (`information_schema`.`TRIGGERS` `tr` left join `OpenRiskManager`.`tisax_object_docs` `d` on(`d`.`object_schema` = `tr`.`TRIGGER_SCHEMA` and `d`.`object_name` = `tr`.`TRIGGER_NAME` and `d`.`object_type` = 'TRIGGER')) where `tr`.`TRIGGER_SCHEMA` = database() and `d`.`id` is null union all select `r`.`ROUTINE_SCHEMA` AS `ROUTINE_SCHEMA`,`r`.`ROUTINE_NAME` AS `ROUTINE_NAME`,'PROCEDURE' AS `PROCEDURE` from (`information_schema`.`ROUTINES` `r` left join `OpenRiskManager`.`tisax_object_docs` `d` on(`d`.`object_schema` = `r`.`ROUTINE_SCHEMA` and `d`.`object_name` = `r`.`ROUTINE_NAME` and `d`.`object_type` = 'PROCEDURE')) where `r`.`ROUTINE_SCHEMA` = database() and `r`.`ROUTINE_TYPE` = 'PROCEDURE' and `d`.`id` is null */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_pdca_carga_por_responsavel`
--

/*!50001 DROP VIEW IF EXISTS `vw_pdca_carga_por_responsavel`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_pdca_carga_por_responsavel` AS select `resp`.`id` AS `responsavel_id`,`resp`.`nome` AS `responsavel_nome`,`resp`.`empresa` AS `empresa`,`resp`.`estabelecimento` AS `estabelecimento`,sum(case when `t`.`status` = 'ABERTA' then 1 else 0 end) AS `abertas`,sum(case when `t`.`status` = 'EM_ANDAMENTO' then 1 else 0 end) AS `em_andamento`,sum(case when `t`.`status` = 'CONCLUIDA' then 1 else 0 end) AS `concluidas`,sum(case when `t`.`status` = 'CANCELADA' then 1 else 0 end) AS `canceladas`,count(`t`.`id`) AS `total` from (`cad_pdca_responsavel` `resp` left join `mov_pdca_tarefa` `t` on(`t`.`responsavel_id` = `resp`.`id`)) group by `resp`.`id`,`resp`.`nome`,`resp`.`empresa`,`resp`.`estabelecimento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_pdca_eficacia`
--

/*!50001 DROP VIEW IF EXISTS `vw_pdca_eficacia`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_pdca_eficacia` AS select `c`.`id` AS `ciclo_id`,`c`.`empresa` AS `empresa`,`c`.`estabelecimento` AS `estabelecimento`,`c`.`risco_id` AS `risco_id`,`r`.`descricao` AS `risco_descricao`,`c`.`gut_inicial` AS `gut_inicial`,`c`.`gut_alvo` AS `gut_alvo`,`c`.`gut_final` AS `gut_final`,case when `c`.`gut_inicial` is null or `c`.`gut_inicial` = 0 then NULL else round((coalesce(`c`.`gut_inicial`,0) - coalesce(`c`.`gut_final`,coalesce(`c`.`gut_alvo`,`c`.`gut_inicial`))) / `c`.`gut_inicial` * 100,2) end AS `eficacia_pct` from (`mov_pdca_ciclo` `c` left join `riscos` `r` on(`r`.`id` = `c`.`risco_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_pdca_pipeline_etapa`
--

/*!50001 DROP VIEW IF EXISTS `vw_pdca_pipeline_etapa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_pdca_pipeline_etapa` AS select `t`.`etapa` AS `etapa`,`t`.`empresa` AS `empresa`,`t`.`estabelecimento` AS `estabelecimento`,sum(case when `t`.`status` = 'ABERTA' then 1 else 0 end) AS `abertas`,sum(case when `t`.`status` = 'EM_ANDAMENTO' then 1 else 0 end) AS `em_andamento`,sum(case when `t`.`status` = 'CONCLUIDA' then 1 else 0 end) AS `concluidas`,count(0) AS `total` from `mov_pdca_tarefa` `t` group by `t`.`etapa`,`t`.`empresa`,`t`.`estabelecimento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_pdca_portfolio`
--

/*!50001 DROP VIEW IF EXISTS `vw_pdca_portfolio`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_pdca_portfolio` AS select `c`.`id` AS `ciclo_id`,`c`.`empresa` AS `empresa`,`c`.`estabelecimento` AS `estabelecimento`,`c`.`risco_id` AS `risco_id`,`r`.`descricao` AS `risco_descricao`,`c`.`titulo` AS `titulo`,`c`.`status` AS `ciclo_status`,`c`.`data_inicio` AS `data_inicio`,`c`.`data_prevista_fim` AS `data_prevista_fim`,`c`.`gut_inicial` AS `gut_inicial`,`c`.`gut_alvo` AS `gut_alvo`,`c`.`gut_final` AS `gut_final`,sum(case when `t`.`status` = 'CONCLUIDA' then 1 else 0 end) / nullif(count(`t`.`id`),0) * 100 AS `progresso_pct` from ((`mov_pdca_ciclo` `c` left join `riscos` `r` on(`r`.`id` = `c`.`risco_id`)) left join `mov_pdca_tarefa` `t` on(`t`.`ciclo_id` = `c`.`id`)) group by `c`.`id`,`c`.`empresa`,`c`.`estabelecimento`,`c`.`risco_id`,`r`.`descricao`,`c`.`titulo`,`c`.`status`,`c`.`data_inicio`,`c`.`data_prevista_fim`,`c`.`gut_inicial`,`c`.`gut_alvo`,`c`.`gut_final` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_pdca_tarefas_atrasadas`
--

/*!50001 DROP VIEW IF EXISTS `vw_pdca_tarefas_atrasadas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_pdca_tarefas_atrasadas` AS select `t`.`id` AS `tarefa_id`,`t`.`ciclo_id` AS `ciclo_id`,`c`.`risco_id` AS `risco_id`,`r`.`descricao` AS `risco_descricao`,`t`.`etapa` AS `etapa`,`t`.`titulo` AS `tarefa_titulo`,`t`.`responsavel_id` AS `responsavel_id`,`resp`.`nome` AS `responsavel_nome`,`t`.`data_prevista` AS `data_prevista`,`t`.`data_inicio` AS `data_inicio`,`t`.`status` AS `status`,to_days(curdate()) - to_days(`t`.`data_prevista`) AS `dias_atraso` from (((`mov_pdca_tarefa` `t` join `mov_pdca_ciclo` `c` on(`c`.`id` = `t`.`ciclo_id`)) left join `riscos` `r` on(`r`.`id` = `c`.`risco_id`)) left join `cad_pdca_responsavel` `resp` on(`resp`.`id` = `t`.`responsavel_id`)) where `t`.`status` in ('ABERTA','EM_ANDAMENTO') and `t`.`data_prevista` is not null and `t`.`data_prevista` < curdate() */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_auditoria_basica`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_auditoria_basica`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_auditoria_basica` AS select `x`.`empresa` AS `empresa`,`x`.`estabelecimento` AS `estabelecimento`,`x`.`area` AS `area`,`x`.`categoria_nome` AS `categoria_nome`,`x`.`atividade_id` AS `atividade_id`,`x`.`atividade_nome` AS `atividade_nome`,`x`.`role_id` AS `role_id`,`x`.`role_nome` AS `role_nome`,`x`.`tipo` AS `tipo`,`x`.`vinculo_created_at` AS `vinculo_created_at`,`x`.`atividade_created_at` AS `atividade_created_at`,`x`.`atividade_updated_at` AS `atividade_updated_at` from `vw_raci_mov_expanded` `x` order by `x`.`vinculo_created_at` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_conflitos_RA`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_conflitos_RA`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_conflitos_RA` AS select `a`.`empresa` AS `empresa`,`a`.`estabelecimento` AS `estabelecimento`,`a`.`area` AS `area`,`c`.`nome` AS `categoria_nome`,`a`.`id` AS `atividade_id`,`a`.`nome` AS `atividade_nome`,`r`.`id` AS `role_id`,`r`.`nome` AS `role_nome` from ((((`raci_atividade` `a` join `raci_mov` `mr` on(`mr`.`atividade_id` = `a`.`id` and `mr`.`tipo` = 'R')) join `raci_mov` `ma` on(`ma`.`atividade_id` = `a`.`id` and `ma`.`tipo` = 'A' and `ma`.`role_id` = `mr`.`role_id`)) join `raci_role` `r` on(`r`.`id` = `mr`.`role_id`)) left join `raci_categoria` `c` on(`c`.`id` = `a`.`categoria_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_controle_cardinalidade_A`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_controle_cardinalidade_A`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_controle_cardinalidade_A` AS select `a`.`id` AS `atividade_id`,`a`.`empresa` AS `empresa`,`a`.`estabelecimento` AS `estabelecimento`,`a`.`area` AS `area`,`c`.`nome` AS `categoria_nome`,`a`.`nome` AS `atividade_nome`,coalesce(`x`.`cnt_A`,0) AS `qtd_A` from ((`raci_atividade` `a` left join `raci_categoria` `c` on(`c`.`id` = `a`.`categoria_id`)) left join (select `raci_mov`.`atividade_id` AS `atividade_id`,count(0) AS `cnt_A` from `raci_mov` where `raci_mov`.`tipo` = 'A' group by `raci_mov`.`atividade_id`) `x` on(`x`.`atividade_id` = `a`.`id`)) where coalesce(`x`.`cnt_A`,0) <> 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_controle_sem_CI`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_controle_sem_CI`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_controle_sem_CI` AS select `a`.`id` AS `atividade_id`,`a`.`empresa` AS `empresa`,`a`.`estabelecimento` AS `estabelecimento`,`a`.`area` AS `area`,`c`.`nome` AS `categoria_nome`,`a`.`nome` AS `atividade_nome`,coalesce(`cntC`.`cnt_C`,0) AS `qtd_C`,coalesce(`cntI`.`cnt_I`,0) AS `qtd_I` from (((`raci_atividade` `a` left join `raci_categoria` `c` on(`c`.`id` = `a`.`categoria_id`)) left join (select `raci_mov`.`atividade_id` AS `atividade_id`,count(0) AS `cnt_C` from `raci_mov` where `raci_mov`.`tipo` = 'C' group by `raci_mov`.`atividade_id`) `cntC` on(`cntC`.`atividade_id` = `a`.`id`)) left join (select `raci_mov`.`atividade_id` AS `atividade_id`,count(0) AS `cnt_I` from `raci_mov` where `raci_mov`.`tipo` = 'I' group by `raci_mov`.`atividade_id`) `cntI` on(`cntI`.`atividade_id` = `a`.`id`)) where coalesce(`cntC`.`cnt_C`,0) = 0 or coalesce(`cntI`.`cnt_I`,0) = 0 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_controle_sem_R`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_controle_sem_R`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_controle_sem_R` AS select `a`.`id` AS `atividade_id`,`a`.`empresa` AS `empresa`,`a`.`estabelecimento` AS `estabelecimento`,`a`.`area` AS `area`,`c`.`nome` AS `categoria_nome`,`a`.`nome` AS `atividade_nome` from ((`raci_atividade` `a` left join `raci_categoria` `c` on(`c`.`id` = `a`.`categoria_id`)) left join (select `raci_mov`.`atividade_id` AS `atividade_id`,count(0) AS `cnt_R` from `raci_mov` where `raci_mov`.`tipo` = 'R' group by `raci_mov`.`atividade_id`) `r` on(`r`.`atividade_id` = `a`.`id`)) where coalesce(`r`.`cnt_R`,0) = 0 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_matriz_atividade`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_matriz_atividade`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_matriz_atividade` AS select `x`.`empresa` AS `empresa`,`x`.`estabelecimento` AS `estabelecimento`,`x`.`area` AS `area`,`x`.`categoria_nome` AS `categoria_nome`,`x`.`atividade_id` AS `atividade_id`,`x`.`atividade_nome` AS `atividade_nome`,group_concat(if(`x`.`tipo` = 'R',`x`.`role_nome`,NULL) order by `x`.`role_nome` ASC separator ', ') AS `responsaveis_R`,group_concat(if(`x`.`tipo` = 'A',`x`.`role_nome`,NULL) order by `x`.`role_nome` ASC separator ', ') AS `aprovadores_A`,group_concat(if(`x`.`tipo` = 'C',`x`.`role_nome`,NULL) order by `x`.`role_nome` ASC separator ', ') AS `consultados_C`,group_concat(if(`x`.`tipo` = 'I',`x`.`role_nome`,NULL) order by `x`.`role_nome` ASC separator ', ') AS `informados_I` from `vw_raci_mov_expanded` `x` group by `x`.`empresa`,`x`.`estabelecimento`,`x`.`area`,`x`.`categoria_nome`,`x`.`atividade_id`,`x`.`atividade_nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_mov_expanded`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_mov_expanded`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_mov_expanded` AS select `a`.`id` AS `atividade_id`,`a`.`empresa` AS `empresa`,`a`.`estabelecimento` AS `estabelecimento`,`a`.`area` AS `area`,`a`.`categoria_id` AS `categoria_id`,`c`.`nome` AS `categoria_nome`,`a`.`nome` AS `atividade_nome`,`r`.`id` AS `role_id`,`r`.`nome` AS `role_nome`,`m`.`tipo` AS `tipo`,`m`.`created_at` AS `vinculo_created_at`,`a`.`created_at` AS `atividade_created_at`,`a`.`updated_at` AS `atividade_updated_at` from (((`raci_mov` `m` join `raci_atividade` `a` on(`a`.`id` = `m`.`atividade_id`)) left join `raci_categoria` `c` on(`c`.`id` = `a`.`categoria_id`)) join `raci_role` `r` on(`r`.`id` = `m`.`role_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_resumo_categoria_area`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_resumo_categoria_area`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_resumo_categoria_area` AS select `a`.`empresa` AS `empresa`,`a`.`estabelecimento` AS `estabelecimento`,`a`.`area` AS `area`,`c`.`nome` AS `categoria_nome`,count(distinct `a`.`id`) AS `atividades`,sum(case when `m`.`tipo` = 'R' then 1 else 0 end) AS `atrib_R`,sum(case when `m`.`tipo` = 'A' then 1 else 0 end) AS `atrib_A`,sum(case when `m`.`tipo` = 'C' then 1 else 0 end) AS `atrib_C`,sum(case when `m`.`tipo` = 'I' then 1 else 0 end) AS `atrib_I` from ((`raci_atividade` `a` left join `raci_categoria` `c` on(`c`.`id` = `a`.`categoria_id`)) left join `raci_mov` `m` on(`m`.`atividade_id` = `a`.`id`)) group by `a`.`empresa`,`a`.`estabelecimento`,`a`.`area`,`c`.`nome` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_raci_resumo_por_role`
--

/*!50001 DROP VIEW IF EXISTS `vw_raci_resumo_por_role`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_raci_resumo_por_role` AS select `r`.`id` AS `role_id`,`r`.`nome` AS `role_nome`,`r`.`empresa` AS `empresa`,`r`.`estabelecimento` AS `estabelecimento`,count(0) AS `total_participacoes`,sum(case when `m`.`tipo` = 'R' then 1 else 0 end) AS `qtd_R`,sum(case when `m`.`tipo` = 'A' then 1 else 0 end) AS `qtd_A`,sum(case when `m`.`tipo` = 'C' then 1 else 0 end) AS `qtd_C`,sum(case when `m`.`tipo` = 'I' then 1 else 0 end) AS `qtd_I` from (`raci_mov` `m` join `raci_role` `r` on(`r`.`id` = `m`.`role_id`)) group by `r`.`id`,`r`.`nome`,`r`.`empresa`,`r`.`estabelecimento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_risco_priorizacao`
--

/*!50001 DROP VIEW IF EXISTS `vw_risco_priorizacao`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_risco_priorizacao` AS select `r`.`id` AS `id`,`r`.`empresa` AS `empresa`,`r`.`estabelecimento` AS `estabelecimento`,`r`.`descricao` AS `descricao`,`r`.`gravidade` AS `gravidade`,`r`.`urgencia` AS `urgencia`,`r`.`tendencia` AS `tendencia`,coalesce(`r`.`gravidade`,0) * coalesce(`r`.`urgencia`,0) * coalesce(`r`.`tendencia`,0) AS `gut_score`,case when coalesce(`r`.`gravidade`,0) * coalesce(`r`.`urgencia`,0) * coalesce(`r`.`tendencia`,0) >= 300 then 'CRITICO' when coalesce(`r`.`gravidade`,0) * coalesce(`r`.`urgencia`,0) * coalesce(`r`.`tendencia`,0) >= 100 then 'ALTO' when coalesce(`r`.`gravidade`,0) * coalesce(`r`.`urgencia`,0) * coalesce(`r`.`tendencia`,0) >= 30 then 'MÉDIO' else 'BAIXO' end AS `classe_gut` from `riscos` `r` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-08 19:48:01
